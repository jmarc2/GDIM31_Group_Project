﻿Goal:
Get highest points by killing enemies.
Attack your enemies from top down, you will be killed if the enemy attacks you from above.


Controls:
W,A,D / Left, Right, Up arrows for Player Movement.
ESC / P for pause game.


Movement:
Your jetpack will run out in the air if you use it for too long.
Land on the ground to recharge your jetpack.
The longer you are on ground, the more fuel your jetpack will be charged for the next flight.
Max charging duration is 5 seconds.
You will be teleported to the other side if you exit the edges of two sides.


THANKS FOR PLAYING!